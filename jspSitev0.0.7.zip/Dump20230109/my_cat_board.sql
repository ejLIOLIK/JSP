-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: my_cat
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `num` int NOT NULL AUTO_INCREMENT,
  `title` char(100) DEFAULT NULL,
  `id` char(20) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `hit` int DEFAULT NULL,
  `content` text,
  `replyCount` int DEFAULT NULL,
  `recmd` int DEFAULT NULL,
  `report` int DEFAULT NULL,
  PRIMARY KEY (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES (2,'페이지테스트2','tester','2022-12-20 14:26:00',1,'페이지테스트를 위한 게시글',0,0,0),(4,'페이지테스트4','tester','2022-12-20 14:26:00',1,'페이지테스트를 위한 게시글',0,0,0),(5,'페이지테스트5','tester','2022-12-20 14:26:00',2,'페이지테스트를 위한 게시글',0,0,0),(6,'페이지테스트6','tester','2022-12-20 14:26:01',0,'페이지테스트를 위한 게시글',0,0,0),(7,'페이지테스트7','tester','2022-12-20 14:26:01',0,'페이지테스트를 위한 게시글',0,0,0),(8,'페이지테스트8','tester','2022-12-20 14:26:01',0,'페이지테스트를 위한 게시글',0,0,0),(9,'페이지테스트9','tester','2022-12-20 14:26:01',0,'페이지테스트를 위한 게시글',0,0,0),(10,'페이지테스트10','tester','2022-12-20 14:26:01',0,'페이지테스트를 위한 게시글',0,0,0),(11,'공지) 신고수 업데이트 예정','공지','2022-12-20 14:26:01',0,'신고수 업데이트 예정',0,0,0),(12,'공지) 추천수 업데이트 예정','공지','2022-12-20 14:26:01',1,'신고수 업데이트 예정',0,0,0),(17,'공지) 추천수 업데이트 예정','공지','2022-12-20 14:26:42',10,'신고수 업데이트 예정',0,4,0),(18,'추천수신고수 SQL적용여부 확인','점검','2022-12-20 14:28:09',2,'내용 확인 중',0,0,0),(20,'리스트, 읽기 페이지에 추천 노출','완료','2022-12-20 14:35:52',7,'완료',0,2,1),(23,'테스트용 신고글3','익명','2022-12-20 15:48:57',0,'신고수 체크용',0,0,0),(24,'테스트용 신고글4','익명','2022-12-20 15:48:57',0,'신고수 체크용',0,0,3),(25,'테스트용 신고글5','익명','2022-12-20 15:48:57',1,'신고수 체크용',0,0,3),(26,'테스트용 신고글6','익명','2022-12-20 15:48:57',4,'신고수 체크용',0,0,0),(27,'신규작성글','신규','2022-12-20 16:23:01',0,'작성글',0,0,0),(28,'신고 테스트 글입니다','아이디','2022-12-20 16:23:21',10,'삭제될 예정임',0,0,0),(29,'로그인 후 게시글 작성 체크','점검','2022-12-21 09:23:46',4,'로그인 시 아이디 자동 입력 확인 중입니다.',0,1,0),(30,'로그아웃 테스트 중','admin','2022-12-21 09:30:57',3,'로그아웃을 테스트합니다.',0,0,0),(31,'관리자에 의해 수정된 게시글','점검','2022-12-21 09:51:51',3,'관리자에 의해 해당 게시글은 수정되었습니다.',0,0,0),(34,'게시글 삭제 아래','점검','2022-12-21 09:52:36',5,'아래 글은 삭제 예정입니다',0,0,0),(35,'첫 게시글','자바','2022-12-21 10:37:27',0,'인사글',0,0,0),(36,'새 프로젝트에서 작성된 글입니다','뉴','2022-12-21 16:21:17',3,'새 프로젝트',0,0,0),(38,'수정된 제목 입니다','수정된이름','2022-12-21 16:33:08',4,'수정된 내용',0,0,0),(41,'테이블 상수처리 테스트 했음','상수처리','2022-12-22 10:18:26',2,'테이블 상수처리 테스트',0,0,0),(43,'쿼리 수정 테스트','쿼리수정','2022-12-22 10:27:24',18,'이상없음',0,0,0),(44,'로그인 후 글쓰기 테스트 v','자바','2022-12-22 14:38:58',1,'로그인 뒤에 작성한 글임',0,0,0),(46,'45번 글은 삭제함 v','자바','2022-12-22 15:09:05',7,'지웠습니다.',0,1,1),(49,'점검 ) 코드 정리 중','테스터','2022-12-23 12:07:37',22,'점검 중입니다',2,0,0),(51,'TEST','admin','2023-01-06 14:13:53',8,'TEST',6,0,0),(54,'0921','자바','2023-01-09 09:21:44',0,'0921',0,0,0);
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-09 11:47:15
