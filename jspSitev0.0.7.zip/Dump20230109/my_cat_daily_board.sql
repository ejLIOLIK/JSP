-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: my_cat
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `daily_board`
--

DROP TABLE IF EXISTS `daily_board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_board` (
  `num` int NOT NULL AUTO_INCREMENT,
  `title` char(100) DEFAULT NULL,
  `ID` char(20) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `hit` int DEFAULT NULL,
  `content` text,
  `replyCount` int DEFAULT NULL,
  `recmd` int DEFAULT NULL,
  `report` int DEFAULT NULL,
  PRIMARY KEY (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_board`
--

LOCK TABLES `daily_board` WRITE;
/*!40000 ALTER TABLE `daily_board` DISABLE KEYS */;
INSERT INTO `daily_board` VALUES (2,'테스트용1','임시ID','2023-01-04 16:16:56',2,'테스트용 내용',0,0,0),(3,'테스트용2','임시ID','2023-01-04 16:16:56',0,'테스트용 내용',0,0,0),(4,'테스트용3','임시ID','2023-01-04 16:16:56',2,'테스트용 내용',0,0,0),(5,'테스트용4','임시ID','2023-01-04 16:16:56',0,'테스트용 내용',0,0,0),(6,'테스트용5','임시ID','2023-01-04 16:16:56',4,'테스트용 내용',0,0,0),(7,'리플 수 게시판 제목에 출력','admin','2023-01-04 16:38:39',0,'확인',0,0,0),(8,'검색 후에도 리플 수 출력','admin','2023-01-04 16:44:03',22,'확인 !',1,0,0),(10,'9번 글은 삭제함','admin','2023-01-04 16:44:44',13,'.',1,2,0),(11,'test','자바','2023-01-04 17:41:06',21,'1234',0,0,0),(12,'조회수 추천수 css','자바','2023-01-04 17:41:21',11,'확인',1,0,0),(13,'v0.0.5','테스터','2023-01-04 17:42:00',78,'내용 있음. ',6,2,0),(14,'수정용','테스터','2023-01-05 14:00:39',120,'123321321',2,4,0),(15,'0537','admin','2023-01-05 17:37:35',8,'0537',0,3,0),(16,'hi','hi','2023-01-05 17:38:48',13,'hihi',0,0,0),(17,'서버 상수 테스트 중','테스터','2023-01-06 09:54:47',84,'123',11,8,0),(18,'메소드 정리','admin','2023-01-06 11:07:55',23,'정리 완료',7,3,0);
/*!40000 ALTER TABLE `daily_board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-09 11:47:15
