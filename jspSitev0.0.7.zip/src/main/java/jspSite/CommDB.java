package jspSite;

import java.sql.SQLException;

public class CommDB extends PostDB {
	
	public String PostNum;
	public Comment[] commentArray;
	
	public void postNumInit(String PostNum) {
		this.PostNum = PostNum;
	}
	
	@Override
	public void pagingInit(String tmpPage) {
		
		dbInit();
		query = "select * from "+SERVER_COMMENT+" where PostNum = "+ PostNum ;
		String mountPostStr = dbCount("select count(*) from "+SERVER_COMMENT+" where PostNum = "+PostNum);

		if(mountPostStr!=null){
			try{
			mountPost = Integer.parseInt(mountPostStr);
			}
			catch(Exception e){
				mountPost = 0; // 임시
			}
		}
		
		if(tmpPage==null){
			curPage = 1;
		}
		else{
			curPage = Integer.parseInt(tmpPage);
		}
		
		if (mountPost==0) { // 존재하지 않을 때의 예외처리
			mountPage = 1;
		}
		else if(mountPost%PAGENUM ==0) {
			mountPage = mountPost/PAGENUM;
		}
		else {
			mountPage = mountPost/PAGENUM +1;
		}
	}
	
	@Override
	public void run() {
		
		commentArray = new Comment[countPagePost()];
		
		int i=0; // 배열 위치
		
		try {
			rs = st.executeQuery(query +" order by date desc limit "+ (curPage-1)*PAGENUM +", "+ PAGENUM);
			
			while(rs.next()) {
				
				commentArray[i] = new Comment();
				commentArray[i].replyNum = rs.getString("replyNum");
				commentArray[i].replyText = rs.getString("replyText");
				commentArray[i].replyId = rs.getString("replyId");
				
				i++;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
				if (st != null) { try { st.close();} catch (SQLException e) { e.printStackTrace();}}
				if (con != null) { try { con.close();} catch (SQLException e) { e.printStackTrace();}}
				if (rs != null) { try { rs.close();} catch (SQLException e) { e.printStackTrace();}}
		}
	}
	
	public void dbInsert(Comment comment) {
		dbUpdate("insert into "+SERVER_COMMENT+" (postNum, replyID, replyText) values ("+ comment.postNum +",'"+ comment.replyId +"','"+ comment.replyText +"')");
		dbUpdate("update "+SERVER_BOARD+" set replyCount = replyCount+1 where num = " + comment.postNum);
	}
}
