package jspSite;

import java.sql.SQLException;

public class PostDB extends DB {

	public final int PAGENUM = 5;
	public int mountPost = 0;
	public int curPage; // 현재 페이지
	public int mountPage; // 전체 페이지
	public Post[] postArray;
	
	String query="";
	
	public void pagingInit(String tmpPage) {
		
		dbInit();
		query = "select * from "+SERVER_BOARD+" ";
		String mountPostStr = dbCount("select count(*) from "+SERVER_BOARD+" ");

		if(mountPostStr!=null){
			try{
			mountPost = Integer.parseInt(mountPostStr);
			}
			catch(Exception e){
				mountPost = 0; // 임시
			}
		}
		
		if(tmpPage==null){
			curPage = 1;
		}
		else{
			curPage = Integer.parseInt(tmpPage);
		}
		
		if (mountPost==0) { // 존재하지 않을 때의 예외처리
			mountPage = 1;
		}
		else if(mountPost%PAGENUM ==0) {
			mountPage = mountPost/PAGENUM;
		}
		else {
			mountPage = mountPost/PAGENUM +1;
		}
	}
	
	public int countPagePost() {

		if(mountPost==0) { //페이지가 존재하지 않을 때의 예외처리
			return 0; // 
		}
		
		if(curPage != mountPage || mountPost%PAGENUM==0) { //마지막 페이지 아님 or 마지막 페이지 게시글 5개 꽉 찰 때
			return PAGENUM;
		}
		else {
			return mountPost%PAGENUM;//마지막 페이지일 때 
		}
	}
	
	public void run() {
		
		postArray = new Post[countPagePost()]; // 게시글 수만큼

		int i=0; // 배열 위치
		
		try {
			rs = st.executeQuery(query + "order by num desc limit "+ (curPage-1)*PAGENUM +", "+ PAGENUM);
			
			while(rs.next()) {
				
				postArray[i] = new Post();
				postArray[i].num = rs.getString("num");
				postArray[i].title = rs.getString("title");
				postArray[i].id = rs.getString("id");
				postArray[i].replyCount = rs.getString("replyCount");
				postArray[i].hit = rs.getString("hit");
				postArray[i].recmd = rs.getString("recmd");
				
				i++;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}  finally {
			if (st != null) { try { st.close();} catch (SQLException e) { e.printStackTrace();}}
			if (con != null) { try { con.close();} catch (SQLException e) { e.printStackTrace();}}
			if (rs != null) { try { rs.close();} catch (SQLException e) { e.printStackTrace();}}
		}
	}
	
	public void dbInsert(Post post) {
		dbUpdate("insert into "+SERVER_BOARD+" (id, title, content, replyCount, hit, recmd, report) value ('"
			+ post.id +"','"+ post.title +"','"+ post.content +"', 0, 0, 0, 0)");
	}

}
