package jspSite;

public class DP {
	
	final int DPNUM = 50;
	public static String boardName;
	
	public String dpTitle() {
		
		String str = "";
		
		str += "게시판 v0.0.7 // " + boardName;
		
		return str;
	}
	
	public String dpLine() {
		String str = "";
		for(int i=0;i<DPNUM;i++) {
			str+="*";
		}
		return str;
	}
}
