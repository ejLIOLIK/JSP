package jspSite;

public class Comment {
	public String replyNum	; //리플 고유번호
	public String replyText; 
	public String replyId; 
	public String postNum; 
}
