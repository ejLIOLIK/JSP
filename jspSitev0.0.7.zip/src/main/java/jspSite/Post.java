package jspSite;

public class Post {
	public String title;
	public String id;
	public String num;
	public String content;
	public String replyCount;
	public String hit;
	public String recmd;
}
