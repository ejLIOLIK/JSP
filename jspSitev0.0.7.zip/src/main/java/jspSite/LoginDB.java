package jspSite;

import java.sql.SQLException;

public class LoginDB extends DB {
	
	public boolean dbCheckEmail(String email) {
		// 아이디가 존재하는지? 존재하지 않으면 존재하지 않는 아이디라고 출력
		try {
			rs = st.executeQuery("select count(*) from "+SERVER_USER+" where email ='" + email +"'");
			
			rs.next();
			if (rs.getString("count(*)").equals("1")) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		return false;
	}
	
	public boolean dbCheckID(String id) {
		// 아이디가 존재하는지? 존재하지 않으면 존재하지 않는 아이디라고 출력
		
		try {
			rs = st.executeQuery("select count(*) from "+SERVER_USER+" where id ='" + id +"'");

			rs.next();
			if (rs.getString("count(*)").equals("1")) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}  
		return false;
	}
	
	public boolean dbCheckPW(String id, String pw) {
		// 패스워드가 일치하는지? 일치하지 않으면 패스워드가 일치하지 않는다고 출력
		try {
			rs = st.executeQuery("select * from "+SERVER_USER+" where id ='"+id+"'");

			while(rs.next()) {
				if(rs.getString("pw").equals(pw)) {
					return true;
				}
			}	
		} catch (SQLException e) {
			e.printStackTrace();
		}	 
		return false;
	}
	
	public boolean dbCheckRight(String num, String id) {
		
		if(id.equals("admin")) {
			return true;
		} // admin은 관리자
		
		try {
			rs = st.executeQuery("select * from "+SERVER_BOARD+" where num = "+num);

			rs.next();
			if(rs.getString("id").equals(id)) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}  
		return false;
	}
	
	public boolean dbCheckRightC(String num, String id) {
		
		if(id.equals("admin")) {
			return true;
		} // admin은 관리자
		
		try {
			rs = st.executeQuery("select * from "+SERVER_COMMENT+" where replynum = "+num);

			rs.next();
			if(rs.getString("replyId").equals(id)) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}  
		return false;
	}

	public void dbUpdate(String email, String id, String pw) {
		try {
			st.executeUpdate("insert into "+SERVER_USER+" (email, id, pw) values ('"+ email +"','"+ id +"','"+ pw +"');");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void dbEdit(Post post) {
		dbUpdate("update "+SERVER_BOARD+" set id='"+ post.id +"', title='"+ post.title +"', content='"+ post.content +"' where num = "+post.num);
	}
	
	public void dbDeletePost(String delNum){
		dbUpdate("delete from "+SERVER_BOARD+" where num="+delNum);
		dbUpdate("delete from "+SERVER_COMMENT+" where PostNum="+delNum); // 리플도 삭제해줌
	}
	
	public void dbEdit(Comment comment){
		dbUpdate("update "+SERVER_COMMENT+" set replyText = '"+ comment.replyText +"' where replyNum = "+ comment.replyNum);
	}
	
	public void dbDeleteComment(String delNum){
		dbUpdate("delete from "+SERVER_COMMENT+" where replyNum="+delNum); 
 		dbUpdate("update "+SERVER_BOARD+" set replyCount = replyCount-1 where num = " + comment.postNum); 
	}
}
