
package jspSite;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DB {

	// 서버 상수 선언부
	public static String serverforName = "com.mysql.cj.jdbc.Driver";
	public static String serverConnection = "jdbc:mysql://localhost:3306/my_cat";
	public static String DB_ID = "root";
	public static String DB_PW = "root";
	
	public static String SERVER_BOARD;
	public static String SERVER_COMMENT;
	public static String SERVER_USER = "register";
	//
	
	public Connection con;
	public Statement st;
	public ResultSet rs;
	public Post post;
	public Comment comment;
	
	public void dbInit() {
		try {
			Class.forName(serverforName);
			con = DriverManager.getConnection(serverConnection, DB_ID, DB_PW);
			st = con.createStatement();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		post = new Post();
		comment = new Comment();
	}
	
	public void dbPostRead(String num) {
		
		try {
			rs = st.executeQuery("select * from "+SERVER_BOARD+" where num="+num);
			rs.next();
				
			post.content = rs.getString("content");
			post.title = rs.getString("title");
			post.id = rs.getString("id");
			post.num = rs.getString("num");
			post.hit = rs.getString("hit");
			post.recmd = rs.getString("recmd");
			post.replyCount = rs.getString("replyCount");
			
		} catch (SQLException e) {
			e.printStackTrace();
		} 	
	}
	
	public String dbCount(String query) {
		
		try {
			rs = st.executeQuery(query);
			rs.next();
			
			return rs.getString("count(*)"); //String값 int변환
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		
		return null;
	}
	
	public void dbUpdate(String q) {
		
		try {
			st.executeUpdate(q);
		} catch (SQLException e) {
			e.printStackTrace();
		} 
	}
	
	public void dbHitDown(String num){
		dbUpdate("update "+SERVER_BOARD+" set hit = hit-1 where num = " + num); // 조회수 늘지 않게
	}
	public void dbHitUp(String num){
		dbUpdate("update "+SERVER_BOARD+" set hit = hit+1 where num = " + num);
	}
	public void dbRecommandUp(String num){
		dbUpdate("update "+SERVER_BOARD+" set recmd = recmd+1 where num = "+num);
	}
}
