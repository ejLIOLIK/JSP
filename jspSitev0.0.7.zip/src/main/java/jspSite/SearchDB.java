package jspSite;

public class SearchDB extends PostDB {
	
	String keyword="";
	
	public SearchDB(String keyword) {
		this.keyword = keyword;
	}
	
	@Override
	public void pagingInit(String tmpPage) {
		
		dbInit();
		query = "select * from "+SERVER_BOARD+" where title like '%"+ keyword +"%' ";
		String mountPostStr = dbCount("select count(*) from "+SERVER_BOARD+" where title like '%"+ keyword +"%' ");

		if(mountPostStr!=null){
			try{
			mountPost = Integer.parseInt(mountPostStr);
			}
			catch(Exception e){
				mountPost = 0; // 임시
			}
		}
		
		if(tmpPage==null){
			curPage = 1;
		}
		else{
			curPage = Integer.parseInt(tmpPage);
		}
		
		if(mountPost%PAGENUM ==0) {
			mountPage = mountPost/PAGENUM;
		}
		else {
			mountPage = mountPost/PAGENUM +1;
		}
	}
}
