package BOARD.DB;

public class memDTO {
	public String id;
	public String email;
	public String date;
}
